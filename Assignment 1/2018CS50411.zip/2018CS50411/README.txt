Manoj Kumar
2018CS50411
4th Year Dual Undergraudate
Computer Science and Engineering
IIT Delhi


Commands to execute:

To create the idx and dict files:

`bash invidx.sh coll_path indexfilename stopwords.txt 0 xml_tags_info.txt`

To create the final result file:

`bash boolsearch.sh queryFile.txt resultFile.txt indexfilename.idx indexfilename.dict`


